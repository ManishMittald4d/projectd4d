import React from "react";

export default function Analytics() {
  return <div>Analytics</div>;
}
