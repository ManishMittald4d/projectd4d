# Elstar React Admin Template (Demo)

This is demo version of Elstar React Admin Template, it included everything that can see in the live demo. This version is for referencing purposes only.

Do <strong>NOT</strong> use the this version to build your app, otherwise, your application will have a lot of unnecessary code & implementation and will lead you to a poor development experience.

## Documentation

Visit [here](https://elstar.themenate.net/docs/documentation/introduction) for the documentation.


## Support
Please feel free to contact us via [our profile page](https://themeforest.net/user/theme_nate) if you encounter any issues, we will provide our best assist.