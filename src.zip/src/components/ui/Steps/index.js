import Steps from './Steps'
import StepItem from './StepItem'

Steps.Item = StepItem

export default Steps