import React from 'react'

const TimeINputBase = () => {
    return (
        <div>TimeINputBase</div>
    )
}

export default TimeINputBase