export default function getDarkModeColor(darkMode) {
    return darkMode ? 'dark' : 'white'
}