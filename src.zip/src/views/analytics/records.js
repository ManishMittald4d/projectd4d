import React, { useState } from "react";
import styles from "./analytics.module.css";
import { setDrawerOpen } from "store/readability/readabilityStateSlice";
import { Dialog, DialogTitle, Grid } from "@mui/material";
import { MdCancel } from "react-icons/md";

export default function Records({ records }) {
  const [open, setOpen] = useState(false);
  const [detailsIndex, setDetailsIndex] = useState(0);

  const handleClose = () => {
    setOpen(false);
  };

  return (
    <div className={styles.listWrapper}>
      <table className={`table table-bordered border-dark ${styles.table}`}>
        <thead>
          <tr>
            <th scope="col">#</th>
            <th scope="col">Endpoint Title</th>
            <th scope="col">Endpoint Url</th>
            <th scope="col">Description</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {records && records.length > 0 ? (
            records.map((item, index) => {
              console.log(item);
              return (
                <tr key={index}>
                  <td>{index + 1}</td>
                  <td>{item.endpointTitle}</td>
                  <td>{item.endpointUrl}</td>
                  <td>{item.description}</td>
                  <td
                    onClick={() => {
                      setOpen(true);
                      setDetailsIndex(index);
                    }}
                    className={styles.viewBtn}
                  >
                    View
                  </td>
                </tr>
              );
            })
          ) : (
            <tr>
              <td colSpan={6} style={{ textAlign: "center" }}>
                No Data Found{" "}
              </td>
            </tr>
          )}
        </tbody>
      </table>
      <Dialog onClose={handleClose} open={open} className={styles.dialogBox}>
        <MdCancel className={styles.crossIcon} onClick={() => handleClose()} />
        <Grid container>
          {Object.entries(records[detailsIndex]).map((item) => (
            <Grid container>
              <Grid item xs={4}>
                {item[0]}
              </Grid>
              <Grid item xs={4}>
                {String(item[1])}
              </Grid>
            </Grid>
          ))}
        </Grid>

        <DialogTitle>API details</DialogTitle>

        <h1>Manish Mittal</h1>
      </Dialog>
    </div>
  );
}
