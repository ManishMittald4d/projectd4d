import React from 'react'
import ResetPasswordForm from './ResetPasswordForm'

const ResetPassword = () => {
	return (
		<ResetPasswordForm disableSubmit={false} />
	)
}

export default ResetPassword