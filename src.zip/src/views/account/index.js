import React from 'react'

const ActivityLog = () => {
	return (
		<div>ActivityLog</div>
	)
}

export default ActivityLog