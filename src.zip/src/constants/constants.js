export const chat_Type = {
  assistant: "assistant",
  user: "user",
};
