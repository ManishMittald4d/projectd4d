export const ADMIN = 'admin'
export const USER = 'user'
export const TEACHER= 'teacher'