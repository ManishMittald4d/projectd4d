export const TOKEN_TYPE = 'Bearer '
export const REQUEST_HEADER_AUTH_KEY = 'Authorization'
export const REQUEST_HEADER_TOKEN_KEY_NAME = 'UserToken'
export const REQUEST_HEADER_FINGERPRINT_KEY_NAME = 'FingerPrintKey'