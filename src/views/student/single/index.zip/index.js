import React, { useState,useEffect } from 'react'
import { AdaptableCard, Loading, Container, DoubleSidedImage } from 'components/shared'
import CustomerProfile from './components/CustomerProfile'
import PaymentHistory from './components/PaymentHistory'
// import CurrentSubscription from './components/CurrentSubscription'
import PaymentMethods from './components/PaymentMethods'
import CurrentSubscriptionStrip from './components/CurrentSubscriptionStrip'
import { useDispatch, useSelector } from 'react-redux'
import { getCustomer, getProjectDashboardData  } from './store/dataSlice'
import reducer from './store'
import { injectReducer } from 'store/index'
import isEmpty from 'lodash/isEmpty'
import useQuery from 'utils/hooks/useQuery'
import { Chart } from 'components/shared';
import { COLORS } from 'constants/chart.constant';
import { Card, Avatar, Button, Notification, toast } from 'components/ui'
import { useNavigate } from 'react-router-dom'
import { MdSchool } from 'react-icons/md'
import { MdBorderColor } from 'react-icons/md'
import { HiMail } from 'react-icons/hi';
import { SlGraph } from 'react-icons/sl';
import { HiPencil } from 'react-icons/hi';
import { FaFileImport } from 'react-icons/fa'
import DemoBoxContent from 'components/docs/DemoBoxContent'
import { deleteCustomer } from './store/dataSlice'
import { openEditCustomerDetailDialog } from './store/stateSlice'
import { HiPencilAlt, HiOutlineTrash } from 'react-icons/hi'
import { ConfirmDialog } from 'components/shared'
import EditCustomerProfile from './components/EditCustomerProfile.js'
injectReducer('crmCustomerDetails', reducer)
const CustomerDetail = () => {

	const dispatch = useDispatch()
	const [timeRange, setTimeRange] = useState(['weekly']);
	
	const [repaint, setRepaint] = useState(false)
	const query = useQuery()

	const data = useSelector((state) => state.crmCustomerDetails.data.profileData)
	const dash = useSelector((state) => state.crmCustomerDetails?.data?.dashboardData?.projectOverviewData
	)

	const loading = useSelector((state) => state.crmCustomerDetails.data.loading)
	useEffect(() => {
		fetchChartData()
	}, [])
	
	const fetchChartData = () => {
		dispatch(getProjectDashboardData())
	}

	useEffect(() => {
		fetchData()
	}, [])
	
	const fetchData = () => {
		const id = 7; //query.get('id')
		if (id) {
			dispatch(getCustomer({id}))
		}
	}
	const CustomerInfoField = ({title, value}) => {
		return (
			<div>
				<span>{title}</span>
				<p className="text-gray-700 dark:text-gray-200 font-semibold">{value}</p>
			</div>
		)
	}

	const CustomerProfileAction = ({id}) => {

		const dispatch = useDispatch()
		const [dialogOpen, setDialogOpen] = useState(false)
	
		const navigate = useNavigate()
	
		const onDialogClose = () => {
			setDialogOpen(false)
		}
	
		const onDialogOpen = () => {
			setDialogOpen(true)
		}
	
		const onDelete = () => {
			setDialogOpen(false)
			dispatch(deleteCustomer({id}))
			navigate('/app/crm/customers')
			toast.push(
				<Notification title={"Successfuly Deleted"} type="success">
					Customer successfuly deleted
				</Notification>
			)
		}
	
		const onEdit = () => {
			dispatch(openEditCustomerDetailDialog())
		}
		return (
			<>
				{/* <Button 
					block 
					icon={<HiOutlineTrash />}
					onClick={onDialogOpen}
				>
					Delete
				</Button> */}
				
				{/* <Button 
					className="bg-neutral-100"
					 
				>	 */}
				<div className="flex justify-end items-center w-full">

					<Button onClick={onEdit} className="text-black bg-neutral-100" shape="sequare" variant="plain" size="xs" icon={<MdBorderColor  className="text-black" />} />

				</div>
					
				{/* </Button> */}
				<ConfirmDialog
					isOpen={dialogOpen}
					onClose={onDialogClose}
					onRequestClose={onDialogClose}
					type="danger"
					title="Delete customer"
					onCancel={onDialogClose}
					onConfirm={onDelete}
					confirmButtonColor="red-600"
				>
					<p>
						Are you sure you want to delete this customer? 
						All record related to this customer will be deleted as well. 
						This action cannot be undone.
					</p>
				</ConfirmDialog>
				<EditCustomerProfile />
			</>
		)
		
	}

	
	return (
		<Container className="h-full">
			<div className="grid grid-cols-4 gap-4 bg-primary-color  pt-8">
			<div className="col-span-1">
			<div className="mb-4">
			<div className="flex flex-col xl:justify-between h-full 2xl:min-w-[360px] mx-auto">
				
				<div className="flex xl:flex-col items-center gap-4">
					<Avatar size={90} shape="circle" src={data.img} />					
					<h4 className="font-bold text-white">{data.name}</h4>
					<h6 className="font-bold text-white">Level 2</h6>
					{/* <span>NewMan Public School</span>
					<span>Wj@gmail.com</span>
					<span>(310)-000-000</span> */}
					<CustomerProfileAction id={data.id} />	
				</div>
				
				{/* <div className="mt-4 flex flex-col xl:flex-row gap-2 bg-cyan-300">
							
				</div> */}
			
			</div>
		
		</div>

		
		
			</div>
		<div className="col-span-3">
			<div className='info-boxes'>
		<div className="w-full">
			<div className="grid grid-rows-1 grid-cols-4 gap-4 pr-5">
				<div>
					<div className="flex justify-between px-4 py-2 items-center h-full  rounded-lg  text-white bg-teal-400">
						<div className="reading-text">
						<p className="text-white">Total Reading</p>
						<p className="text-white">120 Minutes</p>
						</div>
						<div className="reading-icon">
						<Button className="text-white" shape="circle" variant="plain" size="xs" icon={<SlGraph  className="text-white" />} />
						</div>
					</div>
				</div>
				<div>
				<div className="flex justify-between px-4 py-2 rounded-lg items-center h-full  text-white bg-teal-400">
				<div className="reading-text">
						<p className="text-white">Average Accuracy</p>
						<p className="text-white">95%</p>
						</div>
						<div className="reading-icon">
						<Button className="text-white" shape="circle" variant="plain" size="xs" icon={<SlGraph  className="text-white" />} />
						</div>
					</div>
				</div>
				<div>
				<div className="flex justify-between px-4 py-2 rounded-lg items-center h-full  text-white bg-teal-400">
						
				<div className="reading-text">
						<p className="text-white">Comprehension</p>
						<p className="text-white">99%</p>
						</div>
						<div className="reading-icon">
						<Button className="text-white" shape="circle" variant="plain" size="xs" icon={<SlGraph  className="text-white" />} />
						</div>
					</div>
					</div>
					<div>
					<div className="flex justify-between px-4 py-2 rounded-lg items-center h-full text-white bg-teal-400">
						
						<div className="reading-text">
								<p className="text-white">Total WCPM</p>
								<p className="text-white">96%</p>
								</div>
								<div className="reading-icon">
								<Button className="text-white" shape="circle" variant="plain" size="xs" icon={<SlGraph  className="text-white" />} />
								</div>
							</div>

				</div>
		
			</div>
			
		  </div>
		  </div>
		</div>
		

		</div>
		
			<Loading loading={loading}>
				{!isEmpty(data) && (
					<>
						<div className="grid grid-cols-4">
							<div className="col-span-1">
								{/* <CustomerProfile data={data} /> */}
								<div className='info-boxes'>
		<Card className="bg-color-box bg-neutral-100">
			<div className="grid grid-rows-2 grid-cols-2 gap-4 ">
				<div>
					<DemoBoxContent className="row-span-2 h-full bg-white  grid place-content-center">
						<div className="center"><Button shape="circle" variant="plain" size="xs" icon={<HiMail />} /> </div>
						<div className="center text-black">Welcome Email</div>
					</DemoBoxContent>
				</div>
				<div>
					<DemoBoxContent className="row-span-2 h-full bg-white grid place-content-center">
						<div className="center"><Button shape="circle" variant="plain" size="xs" icon={<FaFileImport />} /> </div>
						<div className="center text-black">Add Student</div>
					</DemoBoxContent>
				</div>
				<div>
					<DemoBoxContent className="row-span-2 h-full bg-white grid place-content-center">
						
						<div className="center"><Button shape="circle" variant="plain" size="xs" icon={<FaFileImport />} /> </div>
						<div className="center text-black">Import Stuents</div>
					</DemoBoxContent>
				</div>
				<div>
					<DemoBoxContent className="row-span-2 h-full bg-white grid place-content-center">
						<div className="center"><Button shape="circle" variant="plain" size="xs" icon={<MdSchool />} /> </div>
						<div className="center text-black">Institute</div>
					</DemoBoxContent>
				</div>
				
				
			</div>
		  </Card>
		  </div>
							</div>
							<div className="col-span-3 relative graph-margin">
							{(!isEmpty(dash) && !repaint) && (
										<>
											<div className='grid grid-cols-6 gap-4'>
												
												<div className="bg-white py-16 rounded col-span-4">
													<Chart 
														series={dash.chart[
															[0]].series} 
														xAxis={dash.chart[timeRange[0]].range}
														type="bar"
														customOptions={{colors: [COLORS[0], COLORS[2]], legend: {show: false}}}
													/>
												</div>
												<div className="bg-white py-16 rounded col-span-2 mr-4">
													<Chart 
														series={
															[
															  {
																name: 'Males',
																data: [3, 8, 4, 2, 3, 4, 3 
																]
															  },
															  {
																name: 'Females',
																data: [5, 4, 10, 8, 4, 4, 6 
																]
															  }
															]
	
														} 
														xAxis={dash.chart[timeRange[0]].range}
														type="bar"
														customOptions={
														{colors: [COLORS[0], "#2ebeb3"], 
														legend: {show: false}, 
														stacked: true,
														chart: {
															type: 'bar',
															height: 350,
															stacked: true,
														  },
														
														plotOptions: {
														  bar: {
															horizontal: false,
															barHeight: '80%',
															borderRadius: 2 ,  
															borderRadiusApplication: "around" ,
															borderRadiusWhenStacked: "all" ,
															columnWidth:   "20"
															

														  },
														},
														dataLabels: {
														  enabled: false
														},
														stroke: {
														  width: 1,
														  colors: ["#fff"]
														},
														grid: {
														  xaxis: {
															lines: {
															  show: false
															}
														  }
														},
														yaxis: {
														  min: 0,
														  max: 25,
														},
														xaxis: { 
														  labels: {
															formatter: function (val) {
															  return Math.abs(Math.round(val)) + "%"
															}
														  }
														},
														}}
													/>
												</div>
											</div>
										</>
									)
								}
							</div>
							
						</div>
						<div className="grid grid-cols-2 gap-4 px-4">
							<div className="w-full">
								<AdaptableCard>
									<PaymentHistory />
									<PaymentMethods data={data.paymentMethod} />
								</AdaptableCard>
							</div>
							<div className="w-full">
								<AdaptableCard>
									<PaymentHistory />
									<PaymentMethods data={data.paymentMethod} />
								</AdaptableCard>
							</div>
						</div>
					</>
				)}
			</Loading>
			{(!loading && isEmpty(data)) && (
				<div className="h-full flex flex-col items-center justify-center">
					<DoubleSidedImage 
						src="/img/others/img-2.png"
						darkModeSrc="/img/others/img-2-dark.png"
						alt="No user found!"
					/>
					<h3 className="mt-8">No user found!</h3>
				</div>
			)}
		</Container>
	)
}

export default CustomerDetail
